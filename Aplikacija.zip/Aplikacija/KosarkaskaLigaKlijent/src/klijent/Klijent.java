/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package klijent;

import forme.FrmGlavna;
import java.io.IOException;
import java.net.Socket;
import javax.swing.JOptionPane;
import session.Session;

/**
 *
 * @author KopucHuk
 */
public class Klijent {

    public void start() throws IOException {

        try {
            Socket socket = new Socket("127.0.0.1", 9000);
            Session.getInstance().setSocket(socket);

            FrmGlavna forma = new FrmGlavna();
            forma.setVisible(true);
        } catch (IOException iOException) {
            JOptionPane.showMessageDialog(null, "Server nije pokrenut!", "", JOptionPane.ERROR_MESSAGE);
        }

    }

}
