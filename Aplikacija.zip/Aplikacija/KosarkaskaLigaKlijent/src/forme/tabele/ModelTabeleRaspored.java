/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forme.tabele;

import domen.Utakmica;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author KopucHuk
 */
public class ModelTabeleRaspored extends AbstractTableModel {

    private List<Utakmica> utakmice;
    private String[] kolone = {"Kolo", "Domaćin", "Gost", "Koševa domaćin", "Koševa gost"};

    public ModelTabeleRaspored(List<Utakmica> utakmice) {
        this.utakmice = utakmice;
    }

    @Override
    public int getRowCount() {
        return utakmice.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Utakmica utakmica = utakmice.get(rowIndex);

        switch (columnIndex) {

            case 0:
                return utakmica.getKolo();
            case 1:
                return utakmica.getDomacin().getNaziv();
            case 2:
                return utakmica.getGost().getNaziv();
            case 3:
                return utakmica.getKosevaDomacin();
            case 4:
                return utakmica.getKosevaGost();
            default:
                return "";

        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public void dodaj(List<Utakmica> pom) {
        this.utakmice = pom;
        fireTableDataChanged();
    }

    public void dodajUtakmicu(Utakmica utakmica) {
        utakmice.add(utakmica);
        fireTableDataChanged();
    }

    public void obrisi(int index) {
        utakmice.remove(index);
        fireTableDataChanged();
    }

    public List<Utakmica> vrati() {
        return utakmice;
    }

}
