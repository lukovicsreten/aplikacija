/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forme.tabele;

import domen.Klub;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author KopucHuk
 */
public class ModelTabeleKlubovi extends AbstractTableModel {

    private String[] kolone = {"Naziv", "Dvorana", "Država", "Adresa"};
    private List<Klub> klubovi;

    public ModelTabeleKlubovi(List<Klub> klubovi) {
        this.klubovi = klubovi;
    }

    @Override
    public int getRowCount() {
        return klubovi.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Klub klub = klubovi.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return klub.getNaziv();
            case 1:
                return klub.getHala();
            case 2:
                return klub.getZemlja();
            case 3:
                return klub.getAdresa();
            default:
                return "n/a";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public void dodajKlub(Klub klub) {
        if (!klubovi.contains(klub)) {
            if (klub.isAktivan()) {
                klubovi.add(klub);
            }
        }
        fireTableDataChanged();

    }

    public Klub vratiKlub(int index) {
        return klubovi.get(index);
    }

    public void izmeniKlub(Klub trenutni) {
        for (Klub klub : klubovi) {
            if (klub.getKlubID() == trenutni.getKlubID()) {
                klub = trenutni;
                if (!trenutni.isAktivan()) {
                    klubovi.remove(klub);
                }
            }
        }
        fireTableDataChanged();

    }

}
