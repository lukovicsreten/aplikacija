/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forme.tabele;

import domen.Igrac;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author KopucHuk
 */
public class ModelTabeleIgraci extends AbstractTableModel {

    private List<Igrac> igraci;
    private String[] kolone = {"Broj", "Ime", "Prezime", "Godine", "Pozicija"};

    public ModelTabeleIgraci(List<Igrac> igraci) {
        this.igraci = igraci;
    }

    @Override
    public int getRowCount() {
        return igraci.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Igrac igrac = igraci.get(rowIndex);

        switch (columnIndex) {
            case 0:
                return igrac.getBroj();
            case 1:
                return igrac.getIme();
            case 2:
                return igrac.getPrezime();
            case 3:
                return LocalDate.now().getYear() - igrac.getDatumRodjenja().getYear();
            case 4:
                return igrac.getPozicija();
            default:
                return "n/a";
        }
    }

    @Override
    public String getColumnName(int column) {
        return kolone[column];
    }

    public void dodajIgraca(Igrac igrac) {
        igraci.add(igrac);
        fireTableDataChanged();
    }


    public Igrac vratiIgraca(int index) {
        return igraci.get(index);
    }

   

    public void dodaj(List<Igrac> pom) {
        this.igraci = pom;
        fireTableDataChanged();
    }

}
