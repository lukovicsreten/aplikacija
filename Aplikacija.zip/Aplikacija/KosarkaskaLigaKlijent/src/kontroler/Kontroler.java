/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import domen.Klub;
import domen.Zemlja;
import forme.tabele.ModelTabeleKlubovi;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import request.RequestObject;
import response.ResponseObject;
import session.Session;
import util.ActionCode;
import util.EnumResponseStatus;

/**
 *
 * @author KopucHuk
 */
public class Kontroler {

    public static List<? extends Object> vratiListu(int action) throws IOException {

        RequestObject request = new RequestObject();
        request.setAction(action);

        Socket socket = Session.getInstance().getSocket();

        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        out.writeObject(request);

        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

        try {
            ResponseObject response = (ResponseObject) in.readObject();
            List<?> objects = (List<?>) response.getResponse();
            return objects;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Kontroler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public static void sacuvajIzmeniObjekat(int action, Object object) throws IOException, Exception {

        RequestObject request = new RequestObject();
        request.setAction(action);
        request.setRequest(object);

        Socket socket = Session.getInstance().getSocket();

        ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
        out.writeObject(request);

        ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

        try {
            ResponseObject response = (ResponseObject) in.readObject();
            if (response.getStatus() == EnumResponseStatus.OK) {

            } else {
                throw new Exception(response.getMessage());
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Kontroler.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static List<String> vratiPozicije() {
        List<String> pozicije = new ArrayList<>();
        pozicije.add("1. Plejmejker");
        pozicije.add("2. Bek-šuter");
        pozicije.add("3. Nisko krilo");
        pozicije.add("4. Krilni centar");
        pozicije.add("5. Centar");
        return pozicije;
    }

    public static Klub kreirajKlub(JTextField jtxtNaziv, JTextField jtxtDvorana, JTextField jtxtAdresa, JTextArea jtaOpis, JComboBox jcbDrzave, JCheckBox jchAktivan, JTable jtblKlubovi) {
        try {
            String naziv = jtxtNaziv.getText().trim();
            String hala = jtxtDvorana.getText().trim();
            String adresa = jtxtAdresa.getText().trim();
            String opis = jtaOpis.getText();
            Zemlja zemlja = (Zemlja) jcbDrzave.getSelectedItem();
            boolean aktivan = jchAktivan.isSelected();

            ModelTabeleKlubovi model = (ModelTabeleKlubovi) jtblKlubovi.getModel();

            int klubID = vratiListu(ActionCode.VRATI_SVE_KLUBOVE).size() + 1;
            Klub klub = new Klub(klubID, naziv, hala, adresa, opis, aktivan, zemlja);
            return klub;
        } catch (IOException ex) {
            Logger.getLogger(Kontroler.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

   

}
