/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.IOpstiDomenskiObjekat;
import domen.Utakmica;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author KopucHuk
 */
public class VratiUtakmice extends AbstractSystemOperation {

    private List<Utakmica> utakmice;

    public VratiUtakmice() {
        utakmice = new ArrayList<>();
    }

    @Override
    protected void executeOperation(Object object) throws Exception {
        List<IOpstiDomenskiObjekat> lista = DBBroker.getInstance().vratiListu(new Utakmica());
        for (IOpstiDomenskiObjekat odo : lista) {
            utakmice.add((Utakmica) odo);
        }
    }

    public List<Utakmica> getUtakmice() {
        return utakmice;
    }

}
