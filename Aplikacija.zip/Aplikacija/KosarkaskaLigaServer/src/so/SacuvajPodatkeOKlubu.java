/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.Klub;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class SacuvajPodatkeOKlubu extends AbstractSystemOperation{

    @Override
    protected void executeOperation(Object object)  {
       
        try {
            Klub klub = (Klub) object;
            DBBroker.getInstance().sacuvaj(klub);
        } catch (SQLException ex) {
            Logger.getLogger(SacuvajPodatkeOKlubu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SacuvajPodatkeOKlubu.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
