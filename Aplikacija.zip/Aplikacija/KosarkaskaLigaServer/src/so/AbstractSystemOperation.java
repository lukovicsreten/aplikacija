/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public abstract class AbstractSystemOperation {

    public void execute(Object object) throws Exception {

        try {
            executeOperation(object);
            commit();
        } catch (Exception e) {
            rollback();
            throw e;
        }

    }

    protected abstract void executeOperation(Object object) throws Exception;

    private void commit() {
        try {
            DBBroker.getInstance().commit();
        } catch (SQLException ex) {
            Logger.getLogger(AbstractSystemOperation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AbstractSystemOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void rollback() {
        try {
            DBBroker.getInstance().rollback();
        } catch (SQLException ex) {
            Logger.getLogger(AbstractSystemOperation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(AbstractSystemOperation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
