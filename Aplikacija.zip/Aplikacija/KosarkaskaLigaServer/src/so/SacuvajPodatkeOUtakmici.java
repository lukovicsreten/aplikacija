/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.Utakmica;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class SacuvajPodatkeOUtakmici extends AbstractSystemOperation {

    @Override
    protected void executeOperation(Object object) {
        List<Utakmica> utakmice = (List<Utakmica>) object;
        for (Utakmica utakmica : utakmice) {
            
            try {
                DBBroker.getInstance().sacuvaj(utakmica);
            } catch (SQLException ex) {
                Logger.getLogger(SacuvajPodatkeOUtakmici.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(SacuvajPodatkeOUtakmici.class.getName()).log(Level.SEVERE, null, ex);
            }
             
        }
    }

}
