/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.Igrac;
import domen.Klub;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class IzmeniIgraca extends AbstractSystemOperation{

    @Override
    protected void executeOperation(Object object)  {
        
        try {
            Igrac igrac = (Igrac) object;
            DBBroker.getInstance().izmeni(igrac);
        } catch (SQLException ex) {
            Logger.getLogger(IzmeniIgraca.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(IzmeniIgraca.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
