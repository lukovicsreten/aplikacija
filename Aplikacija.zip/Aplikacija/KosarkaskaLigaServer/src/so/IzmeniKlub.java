/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.Klub;
import java.io.IOException;
import java.sql.SQLException;

/**
 *
 * @author KopucHuk
 */
public class IzmeniKlub extends AbstractSystemOperation{

    @Override
    protected void executeOperation(Object object) throws Exception {
        try {
            Klub klub = (Klub) object;
            DBBroker.getInstance().izmeni(klub);
        } catch (SQLException sQLException) {
            throw new Exception("Klub nije izmenjen!");
        } 
    }
    
}
