/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.IOpstiDomenskiObjekat;
import domen.Igrac;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author KopucHuk
 */
public class VratiIgrace extends AbstractSystemOperation{

    private List<Igrac> igraci;

    public VratiIgrace() {
        igraci = new ArrayList<>();
    }
    
    @Override
    protected void executeOperation(Object object) throws Exception {
        List<IOpstiDomenskiObjekat> lista = DBBroker.getInstance().vratiListu(new Igrac());
        for (IOpstiDomenskiObjekat odo : lista) {
            igraci.add((Igrac) odo);
        }
    }

    public List<Igrac> getIgraci() {
        return igraci;
    }
    
}
