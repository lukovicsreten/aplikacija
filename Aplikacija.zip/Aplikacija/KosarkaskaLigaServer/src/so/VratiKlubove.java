/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package so;

import db.DBBroker;
import domen.IOpstiDomenskiObjekat;
import domen.Klub;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author KopucHuk
 */
public class VratiKlubove extends AbstractSystemOperation {

    private List<Klub> klubovi;

    public VratiKlubove() {
        klubovi = new ArrayList<>();
    }

    @Override
    protected void executeOperation(Object object) throws Exception {
        List<IOpstiDomenskiObjekat> lista = DBBroker.getInstance().vratiListu(new Klub());
        for (IOpstiDomenskiObjekat odo : lista) {
            klubovi.add((Klub) odo);
        }
    }

    public List<Klub> getKlubovi() {
        return klubovi;
    }

}
