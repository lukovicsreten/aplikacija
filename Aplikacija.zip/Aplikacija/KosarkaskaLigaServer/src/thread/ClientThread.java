/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import domen.Igrac;
import domen.Klub;
import domen.Utakmica;
import domen.Zemlja;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import kontroler.Kontroler;
import request.RequestObject;
import response.ResponseObject;
import util.ActionCode;
import util.EnumResponseStatus;

/**
 *
 * @author KopucHuk
 */
public class ClientThread extends Thread {

    private Socket socket;

    public ClientThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            obradiKlijenta();
        } catch (IOException ex) {
            Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void obradiKlijenta() throws IOException, ClassNotFoundException {
        while (true) {

            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
            RequestObject request = (RequestObject) in.readObject();

            ResponseObject response = obradiZahtev(request);
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(response);
            out.flush();

        }
    }

    private ResponseObject obradiZahtev(RequestObject request) {
        ResponseObject response = new ResponseObject();
        int action = request.getAction();

        switch (action) {

            case ActionCode.VRATI_SVE_ZEMLJE : {
            
            try {
                List<Zemlja> zemlje = Kontroler.vratiListuZemalja();
                response.setResponse(zemlje);
                return response;
            } catch (Exception ex) {
                Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
            }
                
            }
            
            case ActionCode.VRATI_SVE_KLUBOVE : {
            
            try {
                List<Klub> klubovi = Kontroler.vratiListuKlubova();
                response.setResponse(klubovi);
                return response;
            } catch (Exception ex) {
                Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
            }
                
            }
            
            case ActionCode.VRATI_SVE_IGRACE : {
            
            try {
                List<Igrac> igraci = Kontroler.vratiListuIgraca();
                response.setResponse(igraci);
                return response;
            } catch (Exception ex) {
                Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
            }
                
            }
            
            case ActionCode.VRATI_SVE_UTAKMICE : {
            
            try {
                List<Utakmica> utakmice = Kontroler.vratiListuUtakmica();
                response.setResponse(utakmice);
                return response;
            } catch (Exception ex) {
                Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
            }
                
            }
            
            case ActionCode.SACUVAJ_KLUB : {
            
                try {
                    Klub klub = (Klub) request.getRequest();
                    Kontroler.sacuvajKlub(klub);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Klub je uspešno sačuvan !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            case ActionCode.SACUVAJ_IGRACA : {
            
                try {
                    Igrac igrac = (Igrac) request.getRequest();
                    Kontroler.sacuvajIgraca(igrac);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Igrač je uspešno sačuvan !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            case ActionCode.SACUVAJ_UTAKMICE : {
            
                try {
                    List<Utakmica> utakmice = (List<Utakmica>) request.getRequest();
                    Kontroler.sacuvajUtakmice(utakmice);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Utakmice su uspesno sačuvane !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            case ActionCode.IZMENI_KLUB : {
            
                try {
                    Klub klub = (Klub) request.getRequest();
                    Kontroler.izmeniKlub(klub);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Klub je uspešno izmenjen !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            case ActionCode.IZMENI_IGRACA : {
            
                try {
                    Igrac igrac = (Igrac) request.getRequest();
                    Kontroler.izmeniIgraca(igrac);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Igrač je uspešno izmenjen !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            case ActionCode.IZMENI_UTAKMICU : {
            
                try {
                    Utakmica utakmica = (Utakmica) request.getRequest();
                    Kontroler.izmeniUtakmicu(utakmica);
                    response.setStatus(EnumResponseStatus.OK);
                    response.setMessage("Utakmica je uspešno izmenjena !");
                } catch (Exception e) {
                    response.setStatus(EnumResponseStatus.ERROR);
                    response.setMessage(e.getMessage());
                }
                return response;
                
            }
            
            default:
                return response;

        }
    }

}
