/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import javax.swing.JLabel;

/**
 *
 * @author KopucHuk
 */
public class SatThread extends Thread{

    private JLabel sat; 

    public SatThread(JLabel sat) {
        this.sat = sat;
    }
    
    @Override
    public void run() {
        
        while (true) {            
            LocalTime vreme = LocalTime.now();
            DateTimeFormatter format = new DateTimeFormatterBuilder().appendPattern("HH:mm:ss").toFormatter();
            sat.setText(vreme.format(format));
        }
        
    }
    
    
    
}
