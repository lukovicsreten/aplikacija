/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class ServerThread extends Thread {

    private ServerSocket ss;

    @Override
    public void run() {

        try {
            ss = new ServerSocket(9000);
            System.out.println("Server je pokrenut");

            while (!interrupted()) {

                Socket socket = ss.accept();
                System.out.println("Klijent se povezao");

                ClientThread client = new ClientThread(socket);
                client.start();

            }

        } catch (IOException ex) {

        }

    }

    public void zaustavi() {
        try {
            this.interrupt();
            ss.close();
            System.out.println("Server je zaustavljen");
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
