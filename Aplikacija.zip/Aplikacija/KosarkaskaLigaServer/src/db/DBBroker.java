/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import domen.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import db.util.DBUtil;
import domen.IOpstiDomenskiObjekat;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class DBBroker {

    private static DBBroker instance;
    private final Connection connection;

    private DBBroker() throws SQLException, IOException {
        String url = DBUtil.getInstance().getUrl();
        String username = DBUtil.getInstance().getUser();
        String password = DBUtil.getInstance().getPass();
        connection = DriverManager.getConnection(url, username, password);
        connection.setAutoCommit(false);
    }

    public static DBBroker getInstance() throws SQLException, IOException {
        if (instance == null) {
            instance = new DBBroker();
        }
        return instance;
    }

  
   
    public void commit() {
        try {
            connection.commit();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void rollback() {
        try {
            connection.rollback();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public List<IOpstiDomenskiObjekat> vratiListu(IOpstiDomenskiObjekat odo) throws SQLException {
        List<IOpstiDomenskiObjekat> lista = new ArrayList<>();
        String upit = "SELECT * FROM " + odo.vratiNazivTabele();
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(upit);
        lista = odo.vratiListu(rs);
        st.close();
        return lista;
    }

    public void sacuvaj(IOpstiDomenskiObjekat odo) throws SQLException {
        String upit = "INSERT INTO "+odo.vratiNazivTabele()+odo.vratiKoloneZaInsert()+" VALUES ("+odo.vratiVrednostiZaInsert()+")";
        Statement st = connection.createStatement();
        st.executeUpdate(upit);
        st.close();
    }

    public void izmeni(IOpstiDomenskiObjekat odo) throws SQLException {
        String upit = "UPDATE "+odo.vratiNazivTabele()+" SET "+odo.vratiVrednostiZaUpdate()+" WHERE "+odo.vratiUslovZaUpdate();
        Statement st = connection.createStatement();
        st.executeUpdate(upit);
        st.close();
    }

    

}
