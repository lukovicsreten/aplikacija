/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kontroler;

import domen.Klub;
import domen.Zemlja;
import domen.Igrac;
import domen.Utakmica;
import java.util.List;
import so.IzmeniIgraca;
import so.IzmeniKlub;
import so.IzmeniUtakmicu;
import so.SacuvajPodatkeOIgracu;
import so.SacuvajPodatkeOKlubu;
import so.SacuvajPodatkeOUtakmici;
import so.VratiIgrace;
import so.VratiKlubove;
import so.VratiUtakmice;
import so.VratiZemlje;

/**
 *
 * @author KopucHuk
 */
public class Kontroler {

    public static List<Zemlja> vratiListuZemalja() throws Exception {
        try {
            VratiZemlje so = new VratiZemlje();
            so.execute(null);
            return so.getMesta();
        } catch (Exception ex) {
            throw new Exception("Lista zemalja nije vracena");
        }
    }

    public static void sacuvajKlub(Klub klub) throws Exception {
        try {
            SacuvajPodatkeOKlubu so = new SacuvajPodatkeOKlubu();
            so.execute(klub);
        } catch (Exception ex) {
            throw new Exception("Klub nije sacuvan");
        }
    }

    public static List<Klub> vratiListuKlubova() throws Exception {
        try {
            VratiKlubove so = new VratiKlubove();
            so.execute(null);
            return so.getKlubovi();
        } catch (Exception ex) {
            throw new Exception("Lista klubova nije vracena");
        }
    }

    public static void izmeniKlub(Klub klub) throws Exception {
        try {
            IzmeniKlub so = new IzmeniKlub();
            so.execute(klub);
        } catch (Exception ex) {
            throw ex;
        }

    }

    public static void sacuvajIgraca(Igrac igrac) throws Exception {
        try {
            SacuvajPodatkeOIgracu so = new SacuvajPodatkeOIgracu();
            so.execute(igrac);
        } catch (Exception ex) {
            throw ex;
        }
    }

    public static List<Igrac> vratiListuIgraca() throws Exception {
        try {
            VratiIgrace so = new VratiIgrace();
            so.execute(null);
            return so.getIgraci();
        } catch (Exception ex) {
            throw new Exception("Lista igraca nije vracena");
        }
    }

    public static void izmeniIgraca(Igrac igrac) throws Exception {
        try {
            IzmeniIgraca so = new IzmeniIgraca();
            so.execute(igrac);
        } catch (Exception ex) {
            throw ex;
        }
    }

    public static List<Utakmica> vratiListuUtakmica() throws Exception {
        try {
            VratiUtakmice so = new VratiUtakmice();
            so.execute(null);
            return so.getUtakmice();
        } catch (Exception ex) {
            throw new Exception("Lista utakmica nije vracena");
        }
    }

    public static void sacuvajUtakmice(List<Utakmica> utakmice) throws Exception {
        try {
            SacuvajPodatkeOUtakmici so = new SacuvajPodatkeOUtakmici();
            so.execute(utakmice);
        } catch (Exception ex) {
            throw ex;
        }
    }

    public static void izmeniUtakmicu(Utakmica utakmica) throws Exception {
        try {
            IzmeniUtakmicu so = new IzmeniUtakmicu();
            so.execute(utakmica);
        } catch (Exception ex) {
            throw ex;
        }
    }

}
