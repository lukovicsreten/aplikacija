/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import db.DBBroker;
import java.io.IOException;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Igrac implements Serializable, IOpstiDomenskiObjekat {

    private int igracID;
    private String ime;
    private String prezime;
    private String pozicija;
    private LocalDate datumRodjenja;
    private int broj;
    private Zemlja zemlja;
    private Klub klub;

    public Igrac() {
    }

    public Igrac(int igracID, String ime, String prezime, String pozicija, LocalDate datumRodjenja, int broj, Zemlja zemlja, Klub klub) {
        this.igracID = igracID;
        this.ime = ime;
        this.prezime = prezime;
        this.pozicija = pozicija;
        this.datumRodjenja = datumRodjenja;
        this.broj = broj;
        this.zemlja = zemlja;
        this.klub = klub;
    }

    public Klub getKlub() {
        return klub;
    }

    public void setKlub(Klub klub) {
        this.klub = klub;
    }

    public Zemlja getZemlja() {
        return zemlja;
    }

    public void setZemlja(Zemlja zemlja) {
        this.zemlja = zemlja;
    }

    public int getIgracID() {
        return igracID;
    }

    public void setIgracID(int igracID) {
        this.igracID = igracID;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getPozicija() {
        return pozicija;
    }

    public void setPozicija(String pozicija) {
        this.pozicija = pozicija;
    }

    public LocalDate getDatumRodjenja() {
        return datumRodjenja;
    }

    public void setDatumRodjenja(LocalDate datumRodjenja) {
        this.datumRodjenja = datumRodjenja;
    }

    public int getBroj() {
        return broj;
    }

    public void setBroj(int broj) {
        this.broj = broj;
    }

    @Override
    public String vratiNazivTabele() {
        return "igrac";
    }

    @Override
    public String vratiVrednostiZaInsert() {
        return getIgracID() + ",'" + getIme() + "','" + getPrezime() + "','" + getPozicija() + "','" + getDatumRodjenja() + "',"
                + getBroj() + "," + getZemlja().getZemljaID() + "," + getKlub().getKlubID();
    }

    @Override
    public List<IOpstiDomenskiObjekat> vratiListu(ResultSet rs) {
        List<IOpstiDomenskiObjekat> igraci = new ArrayList<>();

        try {
            while (rs.next()) {
                int igracID = rs.getInt("IgracID");
                String ime = rs.getString("Ime");
                String prezime = rs.getString("Prezime");
                String pozicija = rs.getString("Pozicija");
                LocalDate datumRodjenja = rs.getDate("DatumRodjenja").toLocalDate();
                int broj = rs.getInt("Broj");
                int zemljaID = rs.getInt("ZemljaID");
                Zemlja zemlja = (Zemlja) DBBroker.getInstance().vratiListu(new Zemlja()).get(zemljaID - 1);
                int klubID = rs.getInt("KlubID");
                Klub klub = null;
                List<IOpstiDomenskiObjekat> klubovi = DBBroker.getInstance().vratiListu(new Klub());
                for (IOpstiDomenskiObjekat odo : klubovi) {
                    Klub k = (Klub) odo;
                    if (k.getKlubID() == klubID) {
                        klub = k;
                    }
                }

                Igrac igrac = new Igrac(igracID, ime, prezime, pozicija, datumRodjenja, broj, zemlja, klub);
                igraci.add(igrac);

            }
        } catch (SQLException sQLException) {
        } catch (IOException ex) {
            Logger.getLogger(Igrac.class.getName()).log(Level.SEVERE, null, ex);
        }

        return igraci;
    }

    @Override
    public String vratiVrednostiZaUpdate() {
        return "IgracID = " + getIgracID() + ", Ime = '" + getIme() + "', Prezime = '" + getPrezime() + "', Pozicija = '" + getPozicija()
                + "', DatumRodjenja = '" + getDatumRodjenja() + "', Broj = " + getBroj() + ", ZemljaID = " + getZemlja().getZemljaID()
                + ", KlubID = " + getKlub().getKlubID();
    }

    @Override
    public String vratiUslovZaUpdate() {
        return "IgracID =" + getIgracID();
    }

    @Override
    public String vratiKoloneZaInsert() {
        return "";
    }

}
