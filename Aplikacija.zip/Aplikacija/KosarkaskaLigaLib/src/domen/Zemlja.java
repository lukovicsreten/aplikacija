/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class Zemlja implements Serializable, IOpstiDomenskiObjekat {
    
    private int ZemljaID;
    private String naziv;

    public Zemlja() {
    }

    public Zemlja(int ZemljaID, String naziv) {
        this.ZemljaID = ZemljaID;
        this.naziv = naziv;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getZemljaID() {
        return ZemljaID;
    }

    public void setZemljaID(int ZemljaID) {
        this.ZemljaID = ZemljaID;
    }

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public String vratiNazivTabele() {
        return "zemlja";
    }

    @Override
    public String vratiVrednostiZaInsert() {
        return null;
    }

    @Override
    public List<IOpstiDomenskiObjekat> vratiListu(ResultSet rs) {
        List<IOpstiDomenskiObjekat> zemlje = new ArrayList<>();
        try {            
            while (rs.next()) {
                
                int zemljaID = rs.getInt("ZemljaID");
                String naziv = rs.getString("Naziv");
                
                Zemlja zemlja = new Zemlja(zemljaID, naziv);
                zemlje.add(zemlja);
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Zemlja.class.getName()).log(Level.SEVERE, null, ex);
        }
        return zemlje;
    }

    @Override
    public String vratiVrednostiZaUpdate() {
        return null;
    }

    @Override
    public String vratiUslovZaUpdate() {
        return null;
    }

    @Override
    public String vratiKoloneZaInsert() {
        return "";
    }
    
   
    
}
