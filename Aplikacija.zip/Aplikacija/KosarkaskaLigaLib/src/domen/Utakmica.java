/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import db.DBBroker;
import java.io.IOException;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class Utakmica implements Serializable, IOpstiDomenskiObjekat {

    private int utakmicaID;
    private LocalDate datum;
    private int kosevaDomacin;
    private int kosevaGost;
    private Klub domacin;
    private Klub gost;
    private int kolo;

    public Utakmica() {
    }

    public Utakmica(int utakmicaID, LocalDate datum, int kosevaDomacin, int kosevaGost, Klub domacin, Klub gost, int kolo) {
        this.utakmicaID = utakmicaID;
        this.datum = datum;
        this.kosevaDomacin = kosevaDomacin;
        this.kosevaGost = kosevaGost;
        this.domacin = domacin;
        this.gost = gost;
        this.kolo = kolo;
    }

    public Klub getGost() {
        return gost;
    }

    public void setGost(Klub gost) {
        this.gost = gost;
    }

    public int getUtakmicaID() {
        return utakmicaID;
    }

    public void setUtakmicaID(int utakmicaID) {
        this.utakmicaID = utakmicaID;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }

    public int getKolo() {
        return kolo;
    }

    public int getKosevaDomacin() {
        return kosevaDomacin;
    }

    public int getKosevaGost() {
        return kosevaGost;
    }

    public void setKolo(int kolo) {
        this.kolo = kolo;
    }

    public void setKosevaDomacin(int kosevaDomacin) {
        this.kosevaDomacin = kosevaDomacin;
    }

    public void setKosevaGost(int kosevaGost) {
        this.kosevaGost = kosevaGost;
    }

    public Klub getDomacin() {
        return domacin;
    }

    public void setDomacin(Klub domacin) {
        this.domacin = domacin;
    }

    @Override
    public String vratiNazivTabele() {
        return "utakmica";
    }

    @Override
    public String vratiVrednostiZaInsert() {
        return "'" + getDatum() + "', " + getKosevaDomacin() + ", " + getKosevaGost() + ", "
                + getDomacin().getKlubID() + ", " + getGost().getKlubID() + ", " + getKolo();
    }

    @Override
    public List<IOpstiDomenskiObjekat> vratiListu(ResultSet rs) {
        List<IOpstiDomenskiObjekat> utakmice = new ArrayList<>();

        try {
            while (rs.next()) {
                int utakmicaID = rs.getInt("UtakmicaID");
                LocalDate datum = rs.getDate("Datum").toLocalDate();
                int kosevaDomacin = rs.getInt("KosevaDomacin");
                int kosevaGost = rs.getInt("KosevaGost");
                int domacinID = rs.getInt("DomacinID");
                int gostID = rs.getInt("GostID");
                int kolo = rs.getInt("Kolo");

                Klub domacin = null;
                Klub gost = null;

                List<IOpstiDomenskiObjekat> klubovi = DBBroker.getInstance().vratiListu(new Klub());
                for (IOpstiDomenskiObjekat odo : klubovi) {
                    Klub k = (Klub) odo;
                    if (k.getKlubID() == domacinID) {
                        domacin = k;
                    }
                    if (k.getKlubID() == gostID) {
                        gost = k;
                    }
                }

                Utakmica utakmica = new Utakmica(utakmicaID, datum, kosevaDomacin, kosevaGost, domacin, gost, kolo);
                utakmice.add(utakmica);
            }
        } catch (SQLException sQLException) {
        } catch (IOException ex) {
            Logger.getLogger(Igrac.class.getName()).log(Level.SEVERE, null, ex);
        }
        return utakmice;
        
    }

    @Override
    public String vratiVrednostiZaUpdate() {
        return "UtakmicaID = " + getUtakmicaID() + ", Datum ='" + getDatum() + "', KosevaDomacin=" + getKosevaDomacin() + ", KosevaGost="
                + getKosevaGost() + ", DomacinID=" + getDomacin().getKlubID() + ", GostID=" + getGost().getKlubID() + ", Kolo=" + getKolo();
    }

    @Override
    public String vratiUslovZaUpdate() {
        return "UtakmicaID = " + getUtakmicaID();
    }

    @Override
    public String vratiKoloneZaInsert() {
        return "(Datum,KosevaDomacin,KosevaGost,DomacinID,GostID,Kolo)";
    }

}
