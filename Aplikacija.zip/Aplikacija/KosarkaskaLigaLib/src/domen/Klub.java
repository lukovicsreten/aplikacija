/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import db.DBBroker;
import java.io.IOException;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author KopucHuk
 */
public class Klub implements Serializable, IOpstiDomenskiObjekat {

    private int klubID;
    private String naziv;
    private String hala;
    private String adresa;
    private String opis;
    private boolean aktivan;
    private Zemlja zemlja;

    public Klub() {
    }

    public Klub(int klubID, String naziv, String hala, String adresa, String opis, boolean aktivan, Zemlja zemlja) {
        this.klubID = klubID;
        this.naziv = naziv;
        this.hala = hala;
        this.adresa = adresa;
        this.opis = opis;
        this.aktivan = aktivan;
        this.zemlja = zemlja;
    }

    public int getKlubID() {
        return klubID;
    }

    public void setKlubID(int klubID) {
        this.klubID = klubID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getHala() {
        return hala;
    }

    public void setHala(String hala) {
        this.hala = hala;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public boolean isAktivan() {
        return aktivan;
    }

    public void setAktivan(boolean aktivan) {
        this.aktivan = aktivan;
    }

    public Zemlja getZemlja() {
        return zemlja;
    }

    public void setZemlja(Zemlja zemlja) {
        this.zemlja = zemlja;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public String toString() {
        return naziv;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Klub) {
            Klub k = (Klub) obj;
            return k.getNaziv().equals(naziv);
        }
        return false;
    }

    @Override
    public String vratiNazivTabele() {
        return "klub";
    }

    @Override
    public String vratiVrednostiZaInsert() {
        return getKlubID() + ",'" + getNaziv() + "','" + getHala() + "','" + getAdresa() + "','" + getOpis() + "',"
                + isAktivan() + "," + getZemlja().getZemljaID();
    }

    @Override
    public List<IOpstiDomenskiObjekat> vratiListu(ResultSet rs) {
        List<IOpstiDomenskiObjekat> klubovi = new ArrayList<>();
        try {

            while (rs.next()) {
                int klubID = rs.getInt("KlubID");
                String naziv = rs.getString("Naziv");
                String hala = rs.getString("Hala");
                String adresa = rs.getString("Adresa");
                String opis = rs.getString("Opis");
                boolean aktivan = rs.getBoolean("Aktivan");
                int zemljaID = rs.getInt("ZemljaID");
                Zemlja zemlja = (Zemlja) DBBroker.getInstance().vratiListu(new Zemlja()).get(zemljaID - 1);

                Klub klub = new Klub(klubID, naziv, hala, adresa, opis, aktivan, zemlja);
                if (klub.isAktivan()) {
                    klubovi.add(klub);
                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(Klub.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klub.class.getName()).log(Level.SEVERE, null, ex);
        }

        return klubovi;
    }

    @Override
    public String vratiVrednostiZaUpdate() {
        return "KlubID = " + getKlubID() + ", Naziv = '" + getNaziv() + "', Hala = '" + getHala() + "', Adresa = '" + getAdresa() + "', Opis = '"
                + getOpis() + "', Aktivan = " + isAktivan() + ", ZemljaID = " + getZemlja().getZemljaID();

    }

    @Override
    public String vratiUslovZaUpdate() {
        return "KlubID = " + getKlubID();
    }

    @Override
    public String vratiKoloneZaInsert() {
        return "";
    }

}
