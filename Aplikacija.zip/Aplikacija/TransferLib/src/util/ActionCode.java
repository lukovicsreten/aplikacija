/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author KopucHuk
 */
public interface ActionCode {
    
    public static final int VRATI_SVE_IGRACE = 1;
    public static final int SACUVAJ_KLUB = 2;
    public static final int IZMENI_KLUB = 3;
    public static final int VRATI_SVE_ZEMLJE = 4;
    public static final int VRATI_SVE_KLUBOVE = 5;
    public static final int SACUVAJ_IGRACA = 6;
    public static final int IZMENI_IGRACA = 7;
    public static final int VRATI_SVE_UTAKMICE =8;
    public static final int SACUVAJ_UTAKMICE = 9;
    public static final int IZMENI_UTAKMICU = 10;
    
}
