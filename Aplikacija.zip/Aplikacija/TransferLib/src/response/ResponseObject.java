/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package response;

import java.io.Serializable;
import util.EnumResponseStatus;

/**
 *
 * @author KopucHuk
 */
public class ResponseObject implements Serializable{
    
    private EnumResponseStatus status;//status odgovora koji salje htttp zahtev
    private String message;
    private Object response;

    public ResponseObject() {
    }

    public ResponseObject(EnumResponseStatus status, String message, Object response) {
        this.status = status;
        this.message = message;
        this.response = response;
    }

    public Object getResponse() {
        return response;
    }

    public void setResponse(Object response) {
        this.response = response;
    }

    public EnumResponseStatus getStatus() {
        return status;
    }

    public void setStatus(EnumResponseStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    
    
}
